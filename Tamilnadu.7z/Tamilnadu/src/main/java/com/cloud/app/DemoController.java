package com.cloud.app;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

	@RequestMapping(value="Print")
	public String Print() {
		return "Poda andavane nama pakam erukan";
	}
}
